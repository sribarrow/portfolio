Create the project folder diss-code, in your local directory.
To start node project, type npm init from within the project folder.
After project init, download project from git.
Install dependencies by typing npm install. This should install all packages saved to package.json.
